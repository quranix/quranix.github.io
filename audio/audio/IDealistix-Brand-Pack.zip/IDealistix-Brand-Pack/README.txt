IDEALISTIX BRAND PACK
Colors: Navy #1F2A44 | Gold #A9741F | Bronze #966316 | Off-white #F5EFE1
Swash gradient: #1F2A44 -> #7A4E14 -> #4A2C0C

1-logo      Main logo. SVG = vector (kono size e kaj kore). PNG = transparent background.
            white = dark background er jonno.
2-youtube   profile-picture-800.png -> YouTube channel icon (upload eta)
            profile-picture-2048-hires.png, profile-picture-4096-hires.png -> hi-res master
            banner-2560x1440.png -> channel banner (logo safe area er vitore)
            video-watermark-150.png -> YouTube Studio > Customization > Branding
3-website   header-logo-30px.png / @2x / @3x / .svg -> blog header
            favicon.ico, favicon.svg, favicon-16/32/48.png, apple-touch-icon-180.png,
            icon-192.png, icon-512.png -> browser tab, phone home screen
4-social    share-image-1200x630.png -> Facebook/Twitter/blog share preview
            profile-picture-1080.png -> Facebook, Instagram etc. profile
